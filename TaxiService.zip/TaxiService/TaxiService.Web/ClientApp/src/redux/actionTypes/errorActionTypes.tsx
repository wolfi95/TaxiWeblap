export const SET_ERROR_MSG = '[Error] Set Error';
export const CLEAR_ERROR_MSG = '[Error] Clear Error';