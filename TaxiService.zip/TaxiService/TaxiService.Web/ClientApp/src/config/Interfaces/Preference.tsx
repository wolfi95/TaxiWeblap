export interface Preference {
    id: number;
    value: boolean;
    text: string;
}