export const mainEmail = "mainemail@smth.com";
export const phoneNumber = "06304569874";
export const lostAndFoundEmail = "lostandfound@smth.com";