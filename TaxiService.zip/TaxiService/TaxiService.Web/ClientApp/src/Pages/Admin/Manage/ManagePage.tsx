import React from 'react';
import './ManagePage.scss';

export default function ManagePage() {
    return (
        <div>
            Admin / Manage
        </div>
    )
}