import React from 'react';
import './UsersPage.scss';

export default function UsersPage() {
    return (
        <div>
            Admin / Users
        </div>
    )
}