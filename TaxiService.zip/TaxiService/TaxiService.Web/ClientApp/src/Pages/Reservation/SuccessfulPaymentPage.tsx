import React from 'react';
import './SuccessfulPaymentPage.scss';

export default function SuccessfulPaymentPage() {
    return (
        <div className="successful-wrapper">
            <span>Your payment was successfull and its status will update shortly! Thank you for choosing our services!</span>
        </div>
    )
}