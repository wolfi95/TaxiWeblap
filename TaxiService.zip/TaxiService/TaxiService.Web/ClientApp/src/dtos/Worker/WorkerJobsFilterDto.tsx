export default interface WorkerJobsFilterDto {
    PageSize: number,
    PageNumber: number,
    HideComplete: boolean
}