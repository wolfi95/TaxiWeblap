export default interface AssignWorkerDto {
    WorkerId: string;
    ReservationId: string;
}