export default interface WorkerDto {
    name: string;
    id: string;
}