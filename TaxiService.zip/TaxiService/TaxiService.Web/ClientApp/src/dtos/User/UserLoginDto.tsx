export default interface UserLoginDto {
    Email: string;
    Password: string;
}