export default interface ContactUsDto {
    message: string;
    reason: string;
}