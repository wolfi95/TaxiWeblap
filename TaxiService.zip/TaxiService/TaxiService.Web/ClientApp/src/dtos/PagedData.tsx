export default interface PagedData<T> {
    data: T[];
    resultCount: number;
}