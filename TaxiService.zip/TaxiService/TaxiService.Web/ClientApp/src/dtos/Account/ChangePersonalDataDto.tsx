export default interface ChangePersonalDataDto {
    Name: string;
    Email: string;
    Address: string;
}