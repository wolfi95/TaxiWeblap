﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dal.Enums
{
    public enum CarType
    {
        Executive = 0,
        Luxury = 1,
        SevenSeater = 2
    }
}
