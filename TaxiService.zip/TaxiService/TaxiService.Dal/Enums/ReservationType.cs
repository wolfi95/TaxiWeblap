﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dal.Enums
{
    public enum ReservationType
    {
        Oneway = 0,
        ByTheHour = 1,
        RightNow = 2
    }
}
