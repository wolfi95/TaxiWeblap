﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dal.Enums
{
    public enum WorkerReservationStatus
    {
        OnTheWay = 3,
        Arrived = 4,
    }
}
