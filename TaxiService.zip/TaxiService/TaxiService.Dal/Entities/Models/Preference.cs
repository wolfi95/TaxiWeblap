﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dal.Entities.Modles
{
    public class Preference
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}
