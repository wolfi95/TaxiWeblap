﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dal.Entities.Authentication
{
    public static class UserRoles
    {
        public const string User = "User";
        public const string Administrator = "Adminsitrator";
        public const string Worker = "Worker";
    }
}
