﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dto.User
{
    public class UserSettingsDto
    {
        public bool AllowEmails { get; set; }
    }
}
