﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dto.User
{
    public class ContactUsDto
    {
        public string Reason { get; set; }
        public string Message{ get; set; }
    }
}
