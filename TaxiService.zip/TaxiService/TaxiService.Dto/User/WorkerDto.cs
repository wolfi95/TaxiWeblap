﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dto.User
{
    public class WorkerDto
    {
        public string Name { get; set; }
        public string Id { get; set; }
    }
}
