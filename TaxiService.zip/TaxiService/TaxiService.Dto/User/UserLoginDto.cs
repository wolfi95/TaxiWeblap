﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dto.User
{
    public class UserLoginDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
