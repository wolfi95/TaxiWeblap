﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiService.Dto.Utils
{
    public class PagerDto
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
